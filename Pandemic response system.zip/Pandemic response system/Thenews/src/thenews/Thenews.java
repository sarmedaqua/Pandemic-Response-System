/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thenews;

/**
 *
 * @author Sarmed Ahmed Usmani
 */
public class Thenews {

    public String headline, summary, details;

    public Thenews() {
    }

    public Thenews(String headline, String summary, String details) {
        this.headline = headline;
        this.summary = summary;
        this.details = details;
    }

    public String getHeadline() {
        return headline;
    }

    public void setHeadline(String headline) {
        this.headline = headline;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}
