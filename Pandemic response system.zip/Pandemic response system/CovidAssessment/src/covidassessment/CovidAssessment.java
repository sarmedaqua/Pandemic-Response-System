/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package covidassessment;

/**
 *
 * @author Sarmed Ahmed Usmani
 */
public class CovidAssessment{
    public Boolean symptoms;
    public Boolean age;
    public Boolean preexistingconditions;
    public Boolean contactwithcovid;
    public Boolean travelhistory;
    public Boolean temp;

    public CovidAssessment() {
    }
    
    public String Evaluation(Boolean symptoms, Boolean age, Boolean preexistingconditions, Boolean contactwithcovid, Boolean travelhistory, Boolean temp){
        int a=0;
        String b="";
        if(symptoms){  a++; }
        
        if(age){ a++;}
        
        if(preexistingconditions){ a++;}
        
        if(contactwithcovid){ a++;}
        
        if(travelhistory){ a++;}
        
        if(temp){ a++;}
         
        if(a==0){ b=("YOU ARE AT NO OR VERY REALLY LOW RISK"); }
        if(a==1 || a==2){ b=("WHILE YOU HAVE LESS CHANCES OF BEING INFECTED BUT \nYOU SHOULD MONITOR YOURSELF"); }
        if(a==3 || a==4){ b=("YOU HAVE CHANCES OF BEING INFECTED, SO YOU SHOULD \nGET PROPER CARE AT HOME"); }
        if(a==5 || a==6){ b=("YOU ARE AT HIGH RISK, PLEASE CONTACT HELPLINE AND \nGET IN TOUCH WITH EMERGENCY CONTACT"); }
        System.out.println();
        return b;
        
    }
    
    public String Summary(Boolean symptoms, Boolean age, Boolean preexistingconditions, Boolean contactwithcovid, Boolean travelhistory, Boolean temp){
        String a,b,c,d,e;
        if(symptoms){ a="YOU HAVE SYMPTOMS OF CORONA INFECTION."; }
        else {a="YOU HAVE SYMPTOMS OF CORONA INFECTION.";}
        
        if(preexistingconditions){ b="YOU HAVE PREEXIXTING CONDITIONS."; }
        else {b="YOU DON'T HAVE PREEXIXTING CONDITIONS.";}
        
        if(contactwithcovid){ c="YOU HAVE HAD CONTACT WITH COVID PATIENT."; }
        else {c="YOU DON'T HAVE ANY CONTACT WITH COVID PATIENT.";}
        
        if(travelhistory){ d="YOU HAVE TRAVELLED TO AN AREA HAVING COVID-19 CASES."; }
        else {d="YOU DON'T HAVE ANY TRAVEL HISTORY.";}
        
        if(temp){ e="YOU HAVE FEVER."; }
        else {e="YOU ARE HAVING NORMAL TEMPERATURE.";}
        return a+"\n"+b+"\n"+c+"\n"+d+"\n"+e;
    } 

    public Boolean getSymptoms() {
        return symptoms;
    }

    public void setSymptoms(Boolean symptoms) {
        this.symptoms = symptoms;
    }

    public Boolean getAge() {
        return age;
    }

    public void setAge(Boolean age) {
        this.age = age;
    }

    public Boolean getPreexistingconditions() {
        return preexistingconditions;
    }

    public void setPreexistingconditions(Boolean preexistingconditions) {
        this.preexistingconditions = preexistingconditions;
    }

    public Boolean getContactwithcovid() {
        return contactwithcovid;
    }

    public void setContactwithcovid(Boolean contactwithcovid) {
        this.contactwithcovid = contactwithcovid;
    }

    public Boolean getTravelhistory() {
        return travelhistory;
    }

    public void setTravelhistory(Boolean travelhistory) {
        this.travelhistory = travelhistory;
    }

    public Boolean getTemp() {
        return temp;
    }

    public void setTemp(Boolean temp) {
        this.temp = temp;
    }
    
    
}
